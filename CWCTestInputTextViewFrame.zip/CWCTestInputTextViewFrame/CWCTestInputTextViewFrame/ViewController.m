//
//  ViewController.m
//  CWCTestInputTextViewFrame
//
//  Created by 陈文昌 on 2017/8/26.
//  Copyright © 2017年 陈文昌. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

/**
 *  输入框
 */
@property (nonatomic, strong) UITextField *myTextField;

/**
 *  输入框底色
 */
@property (nonatomic, strong) UIView *backTextField;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.view.backgroundColor = [UIColor cyanColor];
    self.title = @"测试输入位置";
    
    CGFloat height = self.view.frame.size.height;
    
    [self.view addObserver:self forKeyPath:@"frame" options:NSKeyValueObservingOptionNew || NSKeyValueChangeOldKey context:nil];
    
    
    NSLog(@"====%f",height);
}

- (void)viewDidAppear:(BOOL)animated{

    [super viewDidAppear:animated];
    
    CGFloat height = self.view.frame.size.height;
    NSLog(@"====%f",height);
    
    self.backTextField.frame = CGRectMake(0, CGRectGetHeight(self.view.frame)-44, [UIScreen mainScreen].bounds.size.width, 44);
    self.myTextField.frame = CGRectMake(10, 7, [UIScreen mainScreen].bounds.size.width-20, 30);
    
    [self.backTextField addSubview:self.myTextField];
    
    [self.view addSubview:self.backTextField];
    
    
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context{

    if ([keyPath isEqualToString:@"frame"]) {
        
        NSValue *value = change[@"new"];
        
        CGRect frame = [value CGRectValue];
        
        self.backTextField.frame = CGRectMake(0, CGRectGetHeight(frame)-44, CGRectGetWidth(frame), 44);
        
    }
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    [self.myTextField resignFirstResponder];
    
}

- (UIStatusBarStyle)preferredStatusBarStyle{

    return UIStatusBarStyleLightContent;
    
}

- (UIViewController *)childViewControllerForStatusBarStyle{

    return self;
    
}

- (UIView *)backTextField{

    if (!_backTextField) {
        _backTextField = [[UIView alloc] init];
        _backTextField.backgroundColor = [UIColor lightGrayColor];
    }
    return _backTextField;
}

- (UITextField *)myTextField{

    if (!_myTextField) {
        _myTextField = [[UITextField alloc] init];
        _myTextField.layer.borderWidth = 1.0f;
        _myTextField.layer.borderColor = [UIColor blackColor].CGColor;
        _myTextField.layer.masksToBounds = YES;
        _myTextField.layer.cornerRadius = 4.0f;
    }
    return _myTextField;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
